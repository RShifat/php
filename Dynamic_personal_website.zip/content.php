<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>shifat/content</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&family=Noto+Serif+KR:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
		<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="bootstrap.min.css">
		<link rel="stylesheet" href="style.css">
	</head>
	<body style="background-color: background-color: #3cc1d4;
		background-image: linear-gradient(160deg, #3cc1d4 0%, #0a7b69 100%);">
		<?php
		include("Admin panal/connection.php");
		$display="select * from home";
		$query=mysqli_query($connect,$display);
		while ($show=mysqli_fetch_array($query)) {
		?>
		<div class="container mt-4">
			<div class="row d-flex align-items-center">
				<div class="col-lg-4 col-md-4 col-12 pl-5 float-left">
					<p id="logo_name"><?php echo $show['TITLE']; ?></p>
				</div>
				<div class="col-lg-4 col-md-4 col-12">
					<nav class="navbar navbar-expand-lg navbar-light">
						<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsable">
						<span class="text-center navbar-toggler-icon"></span>
						</button>
						<div class="collapse navbar-collapse" id="collapsable">
							<ul class="navbar-nav ">
								<li class="nav-item  ">
									<a class="nav-link text-white" href="index.php" title="">Home</a>
								</li>
								<li class="nav-item ">
									<a class="nav-link text-dark font-weight-bold" href="content" title="">Contents</a>
								</li>
								<li class="nav-item ">
									<a href="index.php" class="nav-link text-white" title="">Contact</a>
								</li>
							</ul>
						</div>
					</nav>
				</div>
				<div class="col-lg-4 col-md-4 col-12 text-center float-right">
					<img src="Admin Panal/<?php echo $show['IMAGE']; ?>" class="rounded-circle" id="logo_img" style="width: 120px; height: 120px" alt="">
				</div>
			</div>
		</div>
		<?php
		}
		?>
		<section id="portfolio" class="portfolio section-bg">
			<div class="container">
				<div class="section-title m-5">
					<h2 class="text-center">Contents</h2>
				</div>
				<div class="row portfolio-container" data-aos="fade-up" data-aos-delay="100">
					<?php
					include ("Admin panal/connection.php");
					$query5 = "SELECT * FROM content";
					$runquery5= mysqli_query($connect,$query5);
					while($data5=mysqli_fetch_array($runquery5)){
					?>
					<div class="col-lg-4 col-md-6 portfolio-item">
						<div class="portfolio-wrap m-3">
							<a href="<?php echo $data5['LINK' ]; ?>" target="_blank" title=""><img src="Admin panal/<?=$data5['IMAGE']?>" class="img-fluid " alt=""></a>
							<div class="portfolio-links" title="">
								
								<a href="" data-gall="portfolioGallery" class="venobox" title="App 1"><i class="bx bx-plus"></i></a>
								<a href="" target="_blank" title="Visit "><i class="bx bx-link"></i></a>
							</div>
						</div>
					</div>
					<?php
					}
					?>
					
					
					
				</div>
			</div>
		</section>
		<i class="fa fa-arrow-up" id="top" onclick="Topscroll()"></i>
		<?php
		include 'Admin panal/connection.php';
		$display="select * from footer";
		$query=mysqli_query($connect,$display);
		while ($show=mysqli_fetch_array($query)) {
		?>
		<footer class="mt-5">
			<p class="text-center"><b><?php echo $show['DESCRIPTION']; ?> <span style="color:#c0392b">SHIFAT</span></b></p>
		</footer>
		<?php
		}
		?>
		<script>
			
			var mybutton = document.getElementById("top");
			window.onscroll = function(){scrollFunction()};
			function scrollFunction(){
				if (document.body.scrollTop>40 || document.documentElement.scrollTop>40) {
					mybutton.style.display = "block";
				}
				else{
					mybutton.style.display = "none";
				}
			}
			function Topscroll(){
				document.body.scrollTop=0;
				document.documentElement.scrollTop=0;
			}
		</script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	</body>
</html>