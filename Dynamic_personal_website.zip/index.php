<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Shifat</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&family=Noto+Serif+KR:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
		<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Serif:wght@600&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
		<?php
		include("Admin panal/connection.php");
		$display="select * from home";
		$query=mysqli_query($connect,$display);
		while ($show=mysqli_fetch_array($query)) {
		?>
		<div class="container mt-4">
			<div class="row d-flex align-items-center">
				<div class="col-lg-4 col-md-4 col-12 float-left">
					<p id="logo_name"><?php echo $show['TITLE']; ?></p>
				</div>
				<div class="col-lg-4 col-md-4 col-12">
					<nav class="navbar navbar-expand-lg navbar-light">
						<center><button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsable">
						<span class="text-center navbar-toggler-icon"></span>	</button></center>
						<div class="collapse navbar-collapse" id="collapsable">
							<ul class="navbar-nav ">
								<li class="nav-item  ">
									<a class="nav-link text-dark font-weight-bold" href="index.php" title="">Home</a>
								</li>
								<li class="nav-item ">
									<a class="nav-link text-white " href="content.php" title="">Contents</a>
								</li>
								<li class="nav-item ">
									<a href="#contact" class="nav-link text-white " title="">Contact</a>
								</li>
							</ul>
						</div>
					</nav>
				</div>
				<div class="col-lg-4 col-md-4 col-12 text-center float-right">
					<img src="Admin Panal/<?php echo $show['IMAGE']; ?>" class="rounded-circle" id="logo_img" style="width: 125px; height: 125px" alt="">
				</div>
			</div>
		</div>
		<div class="container m-auto">
			<div class="row mt-3" id="content">
				<div class="col-lg-12 col-md-12 col-12 text-white">
					<p><?php echo $show['HEADING']; ?></p>
					<p><?php echo $show['SUBHEADING']; ?></p>
					<a href="resume/shifat.pdf" title=""><button type="button" class="btn btn-dark">Resume</button></a>
				</div>
			</div>
		</div>
		<?php
		}
		?>
		<!-- ======= Portfolio Section ======= -->
		<section id="portfolio" class="portfolio section-bg">
			<div class="container">
				<div class="section-title m-5">
					<h2 class="text-center content_name">Content</h2>
				</div>
				<div class="row portfolio-container" data-aos="fade-up" data-aos-delay="100">
					<?php
					include ("Admin panal/connection.php");
					$query5 = "SELECT * FROM content ORDER BY ID DESC LIMIT 6";
					$runquery5= mysqli_query($connect,$query5);
					while($data5=mysqli_fetch_array($runquery5)){
					?>
					<div class="col-lg-4 col-md-6 portfolio-item">
						<div class="portfolio-wrap m-3">
							<a href="<?php echo $data5['LINK' ]; ?>" target="_blank" title=""><img src="Admin panal/<?=$data5['IMAGE']?>" class="img-fluid " alt=""></a>
							<div class="portfolio-links" title="">
								
								<a href="" data-gall="portfolioGallery" class="venobox" title="App 1"><i class="bx bx-plus"></i></a>
								<a href="" target="_blank" title="Visit "><i class="bx bx-link"></i></a>
							</div>
						</div>
					</div>
					<?php
					}
					?>
					
					
					
				</div>
				<div class="m-5 text-center">
					<a href="content.php" title=""><button type="button" class="btn btn-primary">View More</button></a>
				</div>
			</div>
			</section><!-- End Portfolio Section -->
			<hr>
			<?php
			include("Admin panal/connection.php");
			$display="select * from contact";
			$query=mysqli_query($connect,$display);
			while ($show=mysqli_fetch_array($query)) {
			?>
			<div class="main-body container" id="contact">
				<div class="text-center ">
					<h3 id="contact_name">Get in touch</h3>
					<b class="text-white"><i class="fa fa-address-book mt-4" aria-hidden="true"></i>
					<?php echo $show['ADDRESS'] ?></b>
				</div>
				<?php
				?>
				<div class="main-head">
					<div class="contact-icon text-center mt-2">
						<a href="https://www.facebook.com/login/?cuid=AYjuXezo7qT8InLtuI-EdNAvn-8F1uq4yxOoWhJcPU7OIOAdO4y9RC_QX-CkR4lnisQ_EhvVdtyGPjFoztATPgWwJ4qCBLGnavXowJgzq1Pwa8-b3p6cvwUX4J5BNyndiwIs0VRgjJE2HuCdV57abRsR&next" class="facebook" target="_blank"><i title="Facebook" class="fa fa-facebook" aria-hidden="true"></i>
						</a>
						<a href="https://l.facebook.com/l.php?u=https%3A%2F%2Fwww.instagram.com%2Fshifatur._.rahman%3Ffbclid%3DIwAR1OKtenDGMHrji5nuBFWX0bARb_AiSjSvQPc-vHXN1tONaSgzuMLhGHMT0&h=AT0ASU6ZHnVPAHaquXH9IyGBrAFuqysKPAM6A-kOyzuUevWbV9ZzcgFDjF7R3P-aSeB_4Op-MlF3Csm5JufMqbbXDQFlgGOoRXhn489l8vN4ioydlxG8ONvbj82o13ufiF2N" class="instagram" target="_blank"><i title="Instagram" class="fa fa-instagram" aria-hidden="true"></i>
						</a>
						<a href="https://www.linkedin.com/in/shifatur-rahman/" class="linkedin" target="_blank"><i title="linkedin"  class="fa fa-linkedin" aria-hidden="true"></i>
						</a>
						<a href="https://github.com/RShifat" class="github" target="_blank"><i title="github" class="fa fa-github" aria-hidden="true"></i>
						</a>
						<a href="" target="_blank" class="mail"><i title="Mail" class="fa fa-envelope" aria-hidden="true"></i>
						</a>
					</div>
					<?php
						if (isset($_REQUEST['submit'])) {
						$name=$_REQUEST['name'];
						$email=$_REQUEST['email'];
						$comment=$_REQUEST['message'];
						$to="rshifat010@gmail.com";
						$subject="Message From My website  :";
						$body="Hi,i am $name .$comment";
						$from="From: $email";
						mail($to,$subject,$body,$from);
						}
					?>
					<form action="" class="mt-3" method="post" accept-charset="utf-8">
						<div class="row">
							<div class="col-lg-6">
								<div class="form-group">
									<label for="name"><b>NAME :</b></label>
									<input type="text" name="name" class="form-control" placeholder="Enter name " required >
								</div>
							</div>
							<div class="col-lg-6">
								<div class="form-group">
									<label for="email"><b>EMAIL :</b></label>
									<input type="email" name="email" class="form-control" placeholder="Enter email " required >
								</div>
							</div>
							<div class="col-12">
								<label for="message"><b>MESSAGE :</b></label>
								<textarea class="form-control" rows="5" placeholder="Enter Message" name="message" required></textarea>
							</div>
						</div>
						<center><input type="submit" name="submit" class="btn btn-primary w-50 mt-5" value="SEND"></center>
					</form>
				</div>
			</div>
			<i class="fa fa-arrow-up" id="top" onclick="Topscroll()"></i>
			<!-- Contact section end -->
			<?php
			}
			?>
			<?php
			include 'Admin panal/connection.php';
			$display="select * from footer";
			$query=mysqli_query($connect,$display);
			while ($show=mysqli_fetch_array($query)) {
			?>
			<footer class="mt-5">
				<p class="text-center"><b><?php echo $show['DESCRIPTION']; ?> <span style="color:#c0392b">SHIFAT</span></b></p>
			</footer>
			<?php
			}
			?>
			<script>
			var mybutton = document.getElementById("top");
			window.onscroll = function(){scrollFunction()};
			function scrollFunction(){
				if (document.body.scrollTop>35 || document.documentElement.scrollTop>35) {
					mybutton.style.display = "block";
				}
				else{
					mybutton.style.display = "none";
				}
			}
			function Topscroll(){
				document.body.scrollTop=0;
				document.documentElement.scrollTop=0;
			}
			</script>
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
			<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
		</body>
	</html>