<?php 
require'connection.php';
$id=$_GET['idd'];
$delete="delete from content where ID='$id'";
$query=mysqli_query($connect,$delete);
if ($query) {
	header("location:edit_content.php?deleted");
}
else{
	header("location:edit_content.php?notdeleted");
}
 ?>
