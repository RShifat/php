<?php 
$user='root';
$pass='';
$database="myportfolio";
$server="localhost";
$connect=mysqli_connect($server,$user,$pass,$database);
 ?>