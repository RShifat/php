<?php 
session_start();
 ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Admin</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&family=Noto+Serif+KR:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
		<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="bootstrap.min.css">
		<link rel="stylesheet" href="">
	</head>
	<body>
		<style>
			body{
				width: 100%;
				height: 100vh;
				position: relative;
				background-image: url('map.jpeg');
				background-repeat: no-repeat;
				background-position:center;
				background-position: cover;
			}
			.login_form{
				position: absolute;
				top: 50%;
				left: 50%;
				transform: translate(-50%,-50%);
			}
			form{
				color: #fff;
			}
			input{
				outline: none;
				border: none;
				background: none;
				background-color: transparent;
				border-bottom: 3px solid #fff;
				color: #fff;
			}
		</style>
		<?php 
		include("connection.php");
		if (isset($_REQUEST['submit'])) {
			$name=$_REQUEST['name'];
			$pass=$_REQUEST['password'];
			$search="select * from admin where EMAIL='$name'";
			$query=mysqli_query($connect,$search);
			$emailcount=mysqli_num_rows($query);
			if ($emailcount) {
				$password=mysqli_fetch_array($query);
				$database_password=$password['PASSWORD'];
				$_SESSION['name']=$password['NAME'];
				if ($database_password==true) {
					header("location:user_interface.php?true");
				}
				else{
					header("location:login.php?False");
				}
			}

		}
		 ?>
		<div class="login_form">
			<form action="" method="post" accept-charset="utf-8">
				<b>Email/Name :</b><br>
				<input type="text" name="name" placeholder="Type Your Text" required><br><br>
				<b>Password :</b><br>
				<input type="password" name="password" placeholder="Type Your Text" required><br><br>
				<input type="submit" name="submit" class="btn btn-light" value="Login">
			</form>
		</div>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	</body>
</html>