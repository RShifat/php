<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Admin</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&family=Noto+Serif+KR:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
		<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="bootstrap.min.css">
		<link rel="stylesheet" href="">
	</head>
	<body>
		
			<div class="container">
					<h2 class="text-center">Content</h2>
	
				<div class="row" >
					<?php
					include 'connection.php';
					$display="select * from content order by ID desc limit 6";
					$query=mysqli_query($connect,$display);
					while ($show=mysqli_fetch_array($query)) {
					?>
					<div class="col-lg-6 col-md-6 portfolio-item">
						<div class="portfolio-wrap m-3">
							<img src="<?=$show['IMAGE']?>" class="img-fluid " alt="">
							<div class="portfolio-links" title="">
								
								<a href="" data-gall="portfolioGallery" class="venobox" title="App 1"><i class="bx bx-plus"></i></a>
								<a href="" target="_blank" title="Visit "><i class="bx bx-link"></i></a>
							</div>
						</div>
					</div>
					<?php
					}
					?>	
				</div>
					<center><button type="button" class="btn btn-primary m-5">View More</button></center>
			</div>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	</body>
</html>