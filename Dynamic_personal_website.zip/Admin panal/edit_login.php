<?php 
session_start();

if (!isset($_SESSION['name'])) {
	header('location:login.php');
}
 ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Edit Login</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&family=Noto+Serif+KR:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
		<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="bootstrap.min.css">
		<link rel="stylesheet" href="dashboard.css">
	</head>
	<body>
		<div class="">
			<nav class="navbar navbar-expand-lg bg-dark navbar-light fixed-top">
				<div class="container">
					<a href="" class="navbar-brand text-white" title="">Welcome , <?php echo $_SESSION['name'];?></a>
					<div class="ml-auto">
						<a href="logout.php" class="navbar-brand text-light" title="">Logout</a>
					</div>
				</div>
			</nav>
		</div>
		<div class="">
			<nav class="navbar navbar-expand-lg navbar-light mt-5 container" id="edit_header">
				<ul class="navbar-nav">
					<li class="nav-item ">
						<a class="nav-link text-dark" href="edit_home.php" title="">Edit Home</a>
					</li>
				</ul>
				<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsable">
				<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="collapsable">
					<ul class="navbar-nav ">
						<li class="nav-item ">
							<a class="nav-link text-dark" href="edit_content.php" title="">Edit Contents</a>
						</li>
						<li class="nav-item ">
							<a href="edit_contact.php" class="nav-link text-dark" title="">Edit Contact</a>
						</li>
						<li class="nav-item ">
							<a href="edit_footer.php" class="nav-link text-dark" title="">Edit Footer</a>
						</li>
						<li class="nav-item ">
							<a href="edit_login.php" class="nav-link text-primary" title="">Edit Admin</a>
						</li>
					</ul>
				</div>
			</nav>
		</div>
		<?php 
		include("connection.php");
		$display="select * from admin";
		$query=mysqli_query($connect,$display);
		$show=mysqli_fetch_array($query);
		if (isset($_REQUEST['submit'])) {
			$name=$_REQUEST['name'];
			$email=$_REQUEST['email'];
			$pass=$_REQUEST['pass'];
			$update="UPDATE admin set NAME='$name',EMAIL='$email',PASSWORD='$pass' WHERE ID=1";
			$query=mysqli_query($connect,$update);
			if ($query==true) {
				header("location:edit_login.php?updated");
			}
			else{
				header("location:user_interface.php?Notupdated");
			}
		}
		 ?>
		<div class="container">
			<form action="" method="post" accept-charset="utf-8">
			<b>Name :</b><br><br>
			<input type="text" name="name" value="<?php echo $show['NAME'] ?>"><br><br>
			<b>Email :</b><br><br>
			<input type="text" name="email" value="<?php echo $show['EMAIL'] ?>"><br><br>
			<b>Password :</b><br><br>
			<input type="text" name="pass" value="<?php echo $show['PASSWORD'] ?>">
			<br><br>
			<input type="submit" name="submit" class="btn btn-primary" value="UPDATE">
			</form>
		</div>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	</body>
</html>