<?php
session_start();
if (!isset($_SESSION['name'])) {
	header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Edit Home</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&family=Noto+Serif+KR:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
		<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="bootstrap.min.css">
		<link rel="stylesheet" href="dashboard.css">
	</head>
	<body>
		<div class="">
			<nav class="navbar navbar-expand-lg bg-dark navbar-light fixed-top">
				<div class="container">
					<a href="" class="navbar-brand text-white" title="">Welcome , <?php echo $_SESSION['name'];?></a>
					<div class="ml-auto">
						<a href="logout.php" class="navbar-brand text-light" title="">Logout</a>
					</div>
				</div>
			</nav>
		</div>
		<div class="">
			<nav class="navbar navbar-expand-lg navbar-light mt-5 container" id="edit_header">
				<ul class="navbar-nav">
					<li class="nav-item  ">
						<a class="nav-link text-primary" href="edit_home.php" title="">Edit Home</a>
					</li>
				</ul>
				<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsable">
				<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="collapsable">
					<ul class="navbar-nav ">
						<li class="nav-item ">
							<a class="nav-link text-dark" href="edit_content.php" title="">Edit Contents</a>
						</li>
						<li class="nav-item ">
							<a href="edit_contact.php" class="nav-link text-dark" title="">Edit Contact</a>
						</li>
						<li class="nav-item ">
							<a href="edit_footer.php" class="nav-link text-dark" title="">Edit Footer</a>
						</li>
						<li class="nav-item ">
							<a href="edit_login.php" class="nav-link text-dark " title="">Edit Admin</a>
						</li>
					</ul>
				</div>
			</nav>
		</div>
		<?php 
		include("connection.php");
		$display="select * from home";
		$query=mysqli_query($connect,$display);
		$dataarray=mysqli_fetch_array($query);
		if (isset($_REQUEST['submit'])) {
			$title=$_REQUEST['title'];
			$image=$_FILES['photo'];
			$pname=$image['name'];
			$ppath=$image['tmp_name'];
			$error=$image['error'];
			if ($error==0) {
				$dest="upload/".$pname;
				move_uploaded_file($ppath, $dest);
			}
			$heading=$_REQUEST['heading'];
			$subheading=$_REQUEST['subheading'];
			$update="UPDATE home SET TITLE='$title',IMAGE='$dest',HEADING='$heading',SUBHEADING='$subheading' WHERE ID=1";
			$query=mysqli_query($connect,$update);
			if ($query==true) {
				header("location:edit_home.php?updated");
			}
			else{
				header("location:user_interface.php?Notupdated");
			}

		}
		 ?>
		<form action="" method="post" enctype="multipart/form-data" accept-charset="utf-8">
			<div class="container mt-5">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-12">
						<input type="text" name="title" value="<?php echo $dataarray['TITLE']; ?>"><br><br>
						<input type="file" name="photo" value="<?php echo $dataarray['IMAGE']; ?>" ><br><br>
					</div>
					<div class="col-lg-6 col-md-6 col-12">
						<input type="text" name="heading" value="<?php echo $dataarray['HEADING']; ?>" ><br><br>
						<input type="text" name="subheading" value="<?php echo $dataarray['SUBHEADING']; ?>"
						>
					</div>
				</div>
				<input type="submit" name="submit" value="UPDATE" class="btn btn-danger mt-5">
			</div>
		</form>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	</body>
</html>