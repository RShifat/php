<?php
session_start();
if (!isset($_SESSION['name'])) {
	header('location:login.php');
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Edit Content</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Bungee+Shade&family=Noto+Serif+KR:wght@300&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
		<link href="https://fonts.googleapis.com/css2?family=Great+Vibes&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="bootstrap.min.css">
		<link rel="stylesheet" href="dashboard.css">
	</head>
	<body>
		<div class="">
			<nav class="navbar navbar-expand-lg bg-dark navbar-light fixed-top">
				<div class="container">
					<a href="" class="navbar-brand text-white" title="">Welcome , <?php echo $_SESSION['name'];?></a>
					<div class="ml-auto">
						<a href="logout.php" class="navbar-brand text-light" title="">Logout</a>
					</div>
				</div>
			</nav>
		</div>
		<div class="">
			<nav class="navbar navbar-expand-lg navbar-light mt-5 container" id="edit_header">
				<ul class="navbar-nav">
					<li class="nav-item ">
						<a class="nav-link text-dark" href="edit_home.php" title="">Edit Home</a>
					</li>
				</ul>
				<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsable">
				<span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="collapsable">
					<ul class="navbar-nav ">
						<li class="nav-item ">
							<a class="nav-link text-primary" href="edit_content.php" title="">Edit Contents</a>
						</li>
						<li class="nav-item ">
							<a href="edit_contact.php" class="nav-link text-dark" title="">Edit Contact</a>
						</li>
						<li class="nav-item ">
							<a href="edit_footer.php" class="nav-link text-dark" title="">Edit Footer</a>
						</li>
						<li class="nav-item ">
							<a href="edit_login.php" class="nav-link text-dark" title="">Edit Admin</a>
						</li>
					</ul>
				</div>
			</nav>
		</div>
		<?php
		include("connection.php");
		if (isset($_REQUEST['addtoportfolio'])) {
		$name=$_REQUEST['projectname'];
		$link=$_REQUEST['projectlink'];
		$photo =$_FILES['projectpic'];
		$pname=$photo['name'];
		$ppath=$photo['tmp_name'];
		$error=$photo['error'];
		if ($error==0) {
		$destination='portfoliophoto/'.$pname;
		move_uploaded_file($ppath, $destination);
		$insert="insert into content(IMAGE,NAME,LINK)VALUES('$destination','$name','$link')";
		$query=mysqli_query($connect,$insert);
		}
		}
		?>
		<div class="container">
			<form method="post" action="" enctype="multipart/form-data">
				<div class="form-row">
					<div class="form-group col-md-6">
						<label>Project Screenshot/Image (Minimum 600px X 600px, Maxsize 2mb)</label>
						<div class="custom-file">
							<input type="file" name="projectpic" class="custom-file-input" id="profilepic">
							<label class="custom-file-label" for="projectpic">Choose Pic...</label>
						</div></div>
						
						<div class="form-group col-md-6 mt-auto">
							<label for="name">Project Name</label>
							<input type="name" name="projectname" class="form-control" id="name" placeholder="ToDo List Maker">
						</div>
						
						
						
						<div class="form-group col-md-12">
							<label for="email">Project Link</label>
							<input type="text" name="projectlink" class="form-control" id="email" placeholder="https://whomonugiri.github.io/todo-list-maker/">
						</div>
						<div class="form-group col-md-2 ">
							<input type="submit" name="addtoportfolio" class="btn btn-primary" value="Add To Portfolio">
						</div>
					</div>
				</form>
			</div>
			<div class="container">
				<center>
				<div class="table mt-5">
					<table border="1">
						<tr>
							<td class="text-center bg-dark text-white">ID</td>
							<td class="text-center bg-dark text-white">P IMAGE</td>
							<td class="text-center bg-dark text-white">P NAME</td>
							<td class="text-center bg-dark text-white">P LINK</td>
							<td class="text-center bg-dark text-white">UPDATE</td>
							<td class="text-center bg-dark text-white">DELETE</td>
						</tr>
						<?php
						require("connection.php");
						$display="SELECT * FROM content";
						$query=mysqli_query($connect,$display);
						while ($showdata=mysqli_fetch_array($query)) {
						?>
						<tr>
							<td><?php echo $showdata['ID']; ?> </td>
							<td><img src="<?php echo $showdata['IMAGE']; ?>" width="80" height="80"></td>
							<td><?php echo $showdata['NAME']; ?></td>
							<td><?php echo $showdata['LINK']; ?></td>
							
							<td class="text-center"><a href="portfolio.php?idu=<?php echo $showdata['ID']; ?>" title=""><i class="fa fa-edit"></i></a></td>
							<td class="text-center"><a href="deleteportfolio.php?idd=<?php echo $showdata['ID']; ?>" title=""><i class="fa fa-trash"></i></a></td>
						</tr>
						<?php
						}
						?>
					</table>
				</div>
				</center>
			</div>
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
			<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
		</body>
	</html>