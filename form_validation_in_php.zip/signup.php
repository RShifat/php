<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Sign-up form</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
		<link href="https://fonts.googleapis.com/css2?family=Modak&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="bootstrap.min.css">
	</head>
	<body>
		<?php
		require("connection.php");
		if (isset($_REQUEST['submit'])) {
			$name=mysqli_real_escape_string($connect,$_REQUEST['name']);
			$email=mysqli_real_escape_string($connect,$_REQUEST['email']);
			$password=mysqli_real_escape_string($connect,$_REQUEST['password']);
			// $passhash=password_hash($password, PASSWORD_BCRYPT);
			$photo =$_FILES['photo'];
			$filename=$photo['name'];
			$filepath=$photo['tmp_name'];
			$fileerror=$photo['error'];
			if ($fileerror==0) {
			$destfile='upload/'.$filename;
			move_uploaded_file($filepath, $destfile);
			$emailcheck="SELECT * FROM information WHERE EMAIL='$email'";
			$emailquery=mysqli_query($connect,$emailcheck);
			$emailcount=mysqli_num_rows($emailquery);
			if ($emailcount>0) {
		?>
		<script>
			//alert("Email Already Exists");
		</script>
		<?php
		}
		else{
		    $insert="INSERT INTO information(NAME,EMAIL,PASSWORD,PHOTO)VALUES('$name','$email','$password','$destfile')";
		    $query=mysqli_query($connect,$insert);
		if ($query==true) {
			header("location:signup.php?True");
		}
		else{
			header("location:signup.php?False");
		}
		}
		}
			}
		?>
		<div class="header">
			<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
				<div class="container">
					<h2 class="navbar-brand">Sign-Up Form</h2>
					<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsable">
					<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="collapsable">
						<ul class="navbar-nav ml-auto">
							<li class="nav-item">
								<a href="login.php" class="nav-link text-white" title="">LOGIN</a>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		</div>
		<div class="mt-5 text-center text-warning">
			
			<h1>WELCOME TO SIGN-UP PAGE</h1>
			
		</div>
		<div class="container mt-5">
			<center>
			<div class="form" style="width: 400px; height: 400px;display: flex;justify-content: center;align-items: center;">
				<form action="" method="post" enctype="multipart/form-data" class="form-group" accept-charset="utf-8">
					<input type="file" name="photo" class="form-control"><br>
					<input type="text" name="name" value="" placeholder="Enter Your Name" class="form-control" required><br>
					<input type="text" name="email" value="" placeholder="Enter Your Email" class="form-control" required><br>
					<input type="password" name="password" value="" placeholder="Enter Your Password" class="form-control" required><br>
					<input type="submit" name="submit" class="form-control btn-primary" value="SIGNUP">
					
				</form>
			</div>
			</center>
		</div>
		<br><br><br><br><br>
		<footer class="bg-dark text-center text-white ">
			CREATE BY-SHIFAT
		</footer>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	</body>
</html>