<?php 
session_start();
 ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>login form</title>
		<link rel="stylesheet" href="">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Sign-up form</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
		<link href="https://fonts.googleapis.com/css2?family=Modak&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="bootstrap.min.css">
	</head>
	<body>
		<?php
		require("connection.php");
		if (isset($_REQUEST['submit'])) {
			$email=$_REQUEST['email'];
			$password=$_REQUEST['password'];
			$emailquery="SELECT * FROM information WHERE EMAIL='$email'";
			$emailrun=mysqli_query($connect,$emailquery);
			$emailcount=mysqli_num_rows($emailrun);
			if ($emailcount) {
				$pass=mysqli_fetch_array($emailrun);
				$dbpass=$pass['PASSWORD'];
				// $passverify=password_verify($password, $dbpass);
				$_SESSION['name']=$pass['NAME'];
				if ($password===$dbpass) {
					header("location:home.php");
				}
				else{
					header("location:login.php");
				}
			}
			
		}
		?>
		<div class="header">
			<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
				<div class="container">
					<h2 class="navbar-brand">Login Form</h2>
					<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsable">
					<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="collapsable">
						<ul class="navbar-nav ml-auto">
							<li class="nav-item">
								<a href="signup.php" class="nav-link text-white" title="">SIGNUP</a>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		</div>
		<div class="mt-5 text-center text-warning">
			
			<h1>WELCOME TO LOGIN PAGE</h1>
			
		</div>
		<div class="container mt-5">
			<center>
			<div class="form" style="width: 400px; height: 400px;display: flex;justify-content: center;align-items: center;">
				<form action="" method="post" class=" form-group" accept-charset="utf-8">
					
					<input type="text" name="email" value="" placeholder="Enter Your Email" class="form-control" required=""><br>
					<input type="password" name="password" value="" placeholder="Enter Your Password" class="form-control" required=""><br>
					<input type="submit" name="submit" class="form-control btn-primary" value="LOGIN">
				</form>
			</div>
			</center>
		</div>
		
		<br><br><br><br><br>
		<footer class="bg-dark text-center text-white ">
			CREATE BY-SHIFAT
		</footer>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	</body>
</html>