<?php 
session_start();
if (!isset($_SESSION['name'])) {
	header("location:login.php");
}
 ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Home Page</title>
		<link rel="stylesheet" href="">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Sign-up form</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
		<link href="https://fonts.googleapis.com/css2?family=Modak&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="bootstrap.min.css">
	</head>
	<body>
		<div class="header">
			<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
				<div class="container">
					<h2 class="navbar-brand">INFORMATION</h2>
					<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsable">
					<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="collapsable">
						<ul class="navbar-nav ml-auto">
							<li class="nav-item">
								<a href="logout.php" class="nav-link text-white" title="">LOGOUT</a>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		</div>
		<div class="mt-5 text-center text-warning">
			
			<h1>WELCOME TO INFORMATION DATABASE</h1>
			<h2>Hello, <?php echo $_SESSION['name']; ?></h2>
			
		</div>
		<center>
		<div class="table mt-5">
			<table border="1">
				<tr>
					<td class="text-center bg-dark text-white">ID</td>
					<td class="text-center bg-dark text-white">NAME</td>
					<td class="text-center bg-dark text-white">EMAIL</td>
					<td class="text-center bg-dark text-white">PASSWORD</td>
					<td class="text-center bg-dark text-white">PHOTO</td>
					<td class="text-center bg-dark text-white">DATE</td>
					<td class="text-center bg-dark text-white">UPDATE</td>
					<td class="text-center bg-dark text-white">DELETE</td>
				</tr>
				<?php
				require("connection.php");
				$display="SELECT * FROM information";
				$query=mysqli_query($connect,$display);
				while ($showdata=mysqli_fetch_array($query)) {
				?>
				<tr>
					<td><?php echo $showdata['ID']; ?> </td>
					<td><?php echo $showdata['NAME']; ?></td>
					<td><?php echo $showdata['EMAIL']; ?></td>
					<td><?php echo $showdata['PASSWORD']; ?></td>
					<td><img src="<?php echo $showdata['PHOTO']; ?>" width="80" height="80"></td>
					<td><?php echo $showdata['DATE']; ?></td>
					<td class="text-center"><a href="update.php?idu=<?php echo $showdata['ID']; ?>" title=""><i class="fa fa-edit"></i></a></td>
					<td class="text-center"><a href="delete.php?idd=<?php echo $showdata['ID']; ?>" title=""><i class="fa fa-trash"></i></a></td>
				</tr>
				<?php
				}
				?>
			</table>
		</div>
		</center>
		<br><br><br><br><br>
		<footer class="bg-dark text-center text-white ">
			CREATE BY-SHIFAT
		</footer>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	</body>
</html>