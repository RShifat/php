<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Update page</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
		<link href="https://fonts.googleapis.com/css2?family=Modak&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="bootstrap.min.css">
	</head>
	<body>
		<?php
		require("connection.php");
		$idu=$_GET['idu'];
		$show="SELECT * FROM information WHERE ID='$idu'";
		$query=mysqli_query($connect,$show);
		$arraydata=mysqli_fetch_array($query);
		if (isset($_REQUEST['submit'])) {
			$iddata=$_GET['idu'];
			$name=mysqli_real_escape_string($connect,$_REQUEST['name']);
			$email=mysqli_real_escape_string($connect,$_REQUEST['email']);
			$password=mysqli_real_escape_string($connect,$_REQUEST['password']);
			// $passhash=password_hash($password, PASSWORD_BCRYPT);
			
			$emailcheck="SELECT * FROM information WHERE EMAIL='$email'";
			$emailquery=mysqli_query($connect,$emailcheck);
			$emailcount=mysqli_num_rows($emailquery);
			if ($emailcount>0) {
		?>
		<script>
			alert("Email Already Exists");
		</script>
		<?php
		}
		else{
			
		$Updatedata="UPDATE information SET NAME='$name',EMAIL='$email',PASSWORD='$password' WHERE ID='$iddata'";
		$query=mysqli_query($connect,$Updatedata);
		if ($query) {
			header("location:signup.php?Updated");
		}
		else{
			header("location:signup.php?Notupdated");
		}
		}
		}
		?>
		<div class="header">
			<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
				<div class="container">
					<h2 class="navbar-brand">Update Form</h2>
					<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#collapsable">
					<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse" id="collapsable">
						<ul class="navbar-nav ml-auto">
							<li class="nav-item">
								<a href="login.php" class="nav-link text-white" title="">LOGIN</a>
							</li>
						</ul>
					</div>
				</div>
			</nav>
		</div>
		<div class="mt-5 text-center text-warning">
			
			<h1>WELCOME TO SIGN-UP PAGE</h1>
			
		</div>
		<div class="container mt-5">
			<center>
			<div class="form" style="width: 400px; height: 400px;display: flex;justify-content: center;align-items: center;">
				<form action="" method="post" class=" form-group" accept-charset="utf-8">
					<input type="text" name="name" value="<?php echo $arraydata['NAME']; ?>" placeholder="Enter Your Name" class="form-control" required><br>
					<input type="text" name="email" value="<?php echo $arraydata['EMAIL']; ?>" placeholder="Enter Your Email" class="form-control" required><br>
					<input type="password" name="password" value="<?php echo $arraydata['PASSWORD']; ?>" placeholder="Enter Your Password" class="form-control" required><br>
					<input type="submit" name="submit" class="form-control btn-primary" value="UPDATE">
					
				</form>
			</div>
			</center>
		</div>
		<br><br><br><br><br>
		<footer class="bg-dark text-center text-white ">
			CREATE BY-SHIFAT
		</footer>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
	</body>
</html>