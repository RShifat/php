<?php
$server='localhost';
$username="login";
$password="login10";
$database='login';
$connect=mysqli_connect($server,$username,$password,$database);
if ($connect) {
?>
<script>
	//alert("Database Connected");
</script>
<?php
}
else{
?>
<script>
	alert("Database Not Connected");
</script>
<?php
}
?>