<?php
require("connection.php");
$idd=$_GET['idd'];
$delete="DELETE FROM information WHERE ID=$idd";
$query=mysqli_query($connect,$delete);
if ($query) {
	header("location:home.php?Deleted");
}
else{
	header("location:home.php?Not Deleted");
}
?>